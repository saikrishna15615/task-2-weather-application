# Weather_App
Build Weather App Using XML for User Interface, Java for handling Logic and Open Weather API for getting weather data.
![image](https://github.com/govardhan666/Weather_App/assets/71170706/86e5455d-ebf9-4f82-8f78-b34a5bb848f4)
